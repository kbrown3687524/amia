#!/bin/bash
pymol L63I_auto.pml
