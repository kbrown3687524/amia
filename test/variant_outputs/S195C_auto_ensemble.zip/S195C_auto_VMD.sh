#!/bin/bash
vmd S195C_auto_out.pdb -e S195C_auto.tcl
