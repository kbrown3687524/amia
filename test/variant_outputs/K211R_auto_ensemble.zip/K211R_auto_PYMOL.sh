#!/bin/bash
pymol K211R_auto.pml
