#!/bin/bash
pymol S255G_auto.pml
