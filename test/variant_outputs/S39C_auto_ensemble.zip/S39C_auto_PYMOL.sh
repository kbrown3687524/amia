#!/bin/bash
pymol S39C_auto.pml
