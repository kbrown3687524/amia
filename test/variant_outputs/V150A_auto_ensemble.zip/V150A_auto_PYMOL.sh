#!/bin/bash
pymol V150A_auto.pml
