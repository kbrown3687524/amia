#!/bin/bash
vmd T210A_auto_out.pdb -e T210A_auto.tcl
