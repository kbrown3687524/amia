#!/bin/bash
pymol K215N_auto.pml
