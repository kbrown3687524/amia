#!/bin/bash
pymol E96D_auto.pml
