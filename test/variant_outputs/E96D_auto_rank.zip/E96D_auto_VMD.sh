#!/bin/bash
vmd E96D_auto_out.pdb -e E96D_auto.tcl
