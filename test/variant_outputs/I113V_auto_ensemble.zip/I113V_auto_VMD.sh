#!/bin/bash
vmd I113V_auto_out.pdb -e I113V_auto.tcl
