#!/bin/bash
pymol I113V_auto.pml
