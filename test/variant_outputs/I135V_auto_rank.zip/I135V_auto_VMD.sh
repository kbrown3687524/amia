#!/bin/bash
vmd I135V_auto_out.pdb -e I135V_auto.tcl
