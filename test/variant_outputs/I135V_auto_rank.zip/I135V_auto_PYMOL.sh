#!/bin/bash
pymol I135V_auto.pml
