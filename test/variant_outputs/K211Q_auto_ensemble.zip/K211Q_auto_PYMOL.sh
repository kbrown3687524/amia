#!/bin/bash
pymol K211Q_auto.pml
