#!/bin/bash
vmd K211R_auto_out.pdb -e K211R_auto.tcl
