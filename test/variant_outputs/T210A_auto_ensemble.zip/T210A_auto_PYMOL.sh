#!/bin/bash
pymol T210A_auto.pml
