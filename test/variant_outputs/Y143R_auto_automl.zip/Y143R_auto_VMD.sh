#!/bin/bash
vmd Y143R_auto_out.pdb -e Y143R_auto.tcl
