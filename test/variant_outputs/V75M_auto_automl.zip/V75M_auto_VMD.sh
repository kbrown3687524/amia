#!/bin/bash
vmd V75M_auto_out.pdb -e V75M_auto.tcl
