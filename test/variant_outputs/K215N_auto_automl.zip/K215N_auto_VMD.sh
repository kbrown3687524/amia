#!/bin/bash
vmd K215N_auto_out.pdb -e K215N_auto.tcl
