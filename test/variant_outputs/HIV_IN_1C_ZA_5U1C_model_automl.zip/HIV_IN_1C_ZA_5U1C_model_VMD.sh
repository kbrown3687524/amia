#!/bin/bash
vmd HIV_IN_1C_ZA_5U1C_model_out.pdb -e HIV_IN_1C_ZA_5U1C_model.tcl
