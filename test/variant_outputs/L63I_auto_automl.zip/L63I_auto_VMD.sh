#!/bin/bash
vmd L63I_auto_out.pdb -e L63I_auto.tcl
