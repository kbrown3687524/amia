#!/bin/bash
pymol S24N_auto.pml
