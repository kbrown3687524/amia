#!/bin/bash
vmd I84V_auto_out.pdb -e I84V_auto.tcl
