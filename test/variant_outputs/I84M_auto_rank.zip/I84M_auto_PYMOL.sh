#!/bin/bash
pymol I84M_auto.pml
