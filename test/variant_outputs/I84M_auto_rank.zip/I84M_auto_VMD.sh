#!/bin/bash
vmd I84M_auto_out.pdb -e I84M_auto.tcl
