#!/bin/bash
vmd S119P_auto_out.pdb -e S119P_auto.tcl
