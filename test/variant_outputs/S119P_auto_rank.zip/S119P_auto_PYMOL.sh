#!/bin/bash
pymol S119P_auto.pml
