#!/bin/bash
vmd S255G_auto_out.pdb -e S255G_auto.tcl
