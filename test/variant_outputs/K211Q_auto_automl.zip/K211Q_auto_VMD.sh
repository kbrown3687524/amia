#!/bin/bash
vmd K211Q_auto_out.pdb -e K211Q_auto.tcl
