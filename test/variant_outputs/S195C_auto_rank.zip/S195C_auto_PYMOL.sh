#!/bin/bash
pymol S195C_auto.pml
