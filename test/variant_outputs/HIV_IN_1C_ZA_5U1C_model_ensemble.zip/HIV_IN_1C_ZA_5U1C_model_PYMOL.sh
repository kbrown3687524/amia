#!/bin/bash
pymol HIV_IN_1C_ZA_5U1C_model.pml
