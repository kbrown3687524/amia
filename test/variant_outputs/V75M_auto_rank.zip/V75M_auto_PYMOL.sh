#!/bin/bash
pymol V75M_auto.pml
