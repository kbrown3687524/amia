#!/bin/bash
pymol I220V_auto.pml
