#!/bin/bash
vmd M154I_auto_out.pdb -e M154I_auto.tcl
