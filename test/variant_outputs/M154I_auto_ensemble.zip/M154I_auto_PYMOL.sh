#!/bin/bash
pymol M154I_auto.pml
