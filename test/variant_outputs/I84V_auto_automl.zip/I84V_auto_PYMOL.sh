#!/bin/bash
pymol I84V_auto.pml
