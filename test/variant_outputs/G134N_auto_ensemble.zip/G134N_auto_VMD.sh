#!/bin/bash
vmd G134N_auto_out.pdb -e G134N_auto.tcl
