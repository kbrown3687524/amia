#!/bin/bash
pymol G134N_auto.pml
