#!/bin/bash
vmd T206S_auto_out.pdb -e T206S_auto.tcl
