#!/bin/bash
pymol T206S_auto.pml
