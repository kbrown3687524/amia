#!/bin/bash
vmd S39C_auto_out.pdb -e S39C_auto.tcl
