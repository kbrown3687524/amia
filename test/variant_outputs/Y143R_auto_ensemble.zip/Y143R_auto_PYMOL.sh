#!/bin/bash
pymol Y143R_auto.pml
