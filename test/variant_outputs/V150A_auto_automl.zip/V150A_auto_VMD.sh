#!/bin/bash
vmd V150A_auto_out.pdb -e V150A_auto.tcl
