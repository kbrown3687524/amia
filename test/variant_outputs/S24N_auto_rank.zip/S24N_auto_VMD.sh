#!/bin/bash
vmd S24N_auto_out.pdb -e S24N_auto.tcl
