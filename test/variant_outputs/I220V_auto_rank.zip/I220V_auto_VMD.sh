#!/bin/bash
vmd I220V_auto_out.pdb -e I220V_auto.tcl
